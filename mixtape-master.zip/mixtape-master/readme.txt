This templates was made by https://colorlib.com.  More awesome templates are available here: https://colorlib.com/wp/templates/

Included resources: 
Music is from Bensound. More info on licensing here: https://www.bensound.com/licensing
